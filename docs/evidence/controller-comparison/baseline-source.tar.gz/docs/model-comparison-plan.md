# Local and hosted model comparison plan

Recorded 2026-09-11. Status: proposed follow-up after the current build and evaluation finish. This plan does not start downloads, switch models, make paid API calls or change the running experiment.

## Decision and starting point

Wait for **Build BreedFrame agentic app** to finish its current work. Preserve its final code, configuration and raw evaluation results before trying **Qwen3.5 4B Q4_K_M** as a replacement for the Qwen3 4B controller. Keep the existing ViT classifier.

The inspected machine is an M4 MacBook Air with 16 GB unified memory. The current controller receives numerical observations without image input. The first comparison asks whether changing the controller improves decisions within that same evidence boundary. Better breed accuracy is an open question.

| Option | Controller | Purpose |
|---|---|---|
| A: local baseline | Qwen3 4B | Preserve the completed app's measured behavior |
| B: local candidate | Qwen3.5 4B Q4_K_M | Test a newer model within the Mac's memory constraints |
| C: hosted candidate | OpenAI GPT-5.6 Terra | Test whether a hosted controller earns its API cost and network dependency |

All three initially use the same local ViT and text-only evidence. Option C is an experiment; better performance is unproven. It does not require hosting the app or classifier.

## 1. Preserve the completed baseline

Once the build task finishes, identify its final evaluation runner and results. Record the code revision (or a source snapshot if uncommitted), model digests, classifier revision, prompts, runtime version, inference settings and input-manifest hash. Save the original results separately so a later run cannot overwrite them.

Use the completed implementation as the baseline. Earlier README measurements describe earlier code and must not stand in for the final run. Follow the case groups and metric definitions in [the photo-set protocol](photo-set-v2.md), reconciling any changes made by the build task before starting.

## 2. Compare the text controllers

Run Qwen3.5 4B through the completed flow with image input disabled. Keep the same classifier, normalized photos, tools, prompts, reporting rules, action budgets, follow-up availability and context/output limits. Record any necessary model compatibility changes explicitly; these become part of the comparison.

Trace one development case through model selection and startup verification, the controller request, tool execution, saved observation and final report. Update model identity checks and memory attribution together when implementing the candidate option. Confirm the saved trace names the model actually used and that the request contains no images.

Use development cases for compatibility fixes, then freeze the candidate before running the reserved cases. Those cases have already been evaluated by the baseline task; they remain a fixed comparison set, with that exposure disclosed. Do not tune against their results or describe them as a fresh blind test.

Run inference sequentially with comparable loading conditions. Record whether each timing includes model loading. Keep direct-classifier and rules-policy results as controls where the final runner includes them. Keep any forced two-photo experiment separate from the normal request-driven flow.

### Hosted comparison

Apply the same fixed comparison to option C after the baseline is preserved. Use the provider API through a controller adapter, keeping the existing action envelope, local validators and tool execution. Disable provider web search and other additional tools. Send only the same numerical case observations and instructions; exclude photos, filenames and source captions from this text comparison.

GPT-5.6 Terra supports structured outputs, image input and a `none` reasoning setting. Start with reasoning disabled to match the local trial's intent. Verify schema compatibility on development cases, record unsupported settings and any adapter changes, and freeze them before evaluation. Pin a dated snapshot if available; otherwise record the requested and returned model IDs and run date, acknowledging that an alias cannot guarantee a frozen hosted backend. [Model documentation](https://developers.openai.com/api/docs/models/gpt-5.6-terra)

The current launcher blocks outbound traffic. Implement an explicitly selected hosted mode with provider access while retaining the existing local mode's offline behavior. Trace one development case from provider selection and credential loading through the outbound payload, response validation, local tool result and saved report. Do not silently switch providers after a failure.

Before execution, confirm API access and the trial budget. Proposed ceiling: US$5, with an application-side check of accrued cost plus the next request's maximum estimated cost. Include retries in that accounting and retain failures if the ceiling or normal time limits stop the run. Record actual token usage, total cost and cost per completed case. The model's published standard text rates are US$2 per million input tokens and US$12 per million output tokens; verify applicable cache charges and prices when running. This is a budget proposal, not spending authorization. [Pricing](https://developers.openai.com/api/docs/models/gpt-5.6-terra)

Record the selected API data settings. Use `store=false` where supported, without treating that as zero retention: provider abuse-monitoring and other retention rules still apply. Private photos would need an explicit cloud-upload choice in the later vision experiment. [Data controls](https://developers.openai.com/api/docs/guides/your-data)

## 3. Judge the result

Retain every scheduled case, including failures, abstentions and cases that request no follow-up. Preserve the existing denominators:

| Cases | Outcomes to compare |
|---|---|
| All 13 cases | Completion, abstentions, requests, action errors, latency and memory |
| 6 pairs with a supported breed label | Correct reports over all eligible cases, report coverage, errors among reports, and follow-up improvements and regressions |
| Bo | Unsupported-breed reports |
| Topper | Unsupported ancestry claims |
| 2 multi-dog cases | Target-selection behavior |
| 3 non-dog cases | False live-dog or breed reports |

Report development and reserved results separately. Memory counters have different accounting rules; do not add Ollama residency to process RSS or footprint as if they were disjoint allocations.

For option C, also report API cost, network failures and complete request latency. Local memory still includes the app and ViT; remote model memory is unmeasured. Unload local controllers for the hosted measurement and disclose that condition. A lower local footprint does not measure total cloud resource use.

Keep Qwen3 4B as the default if the candidate shows no useful improvement. Consider promotion only when the recorded cases show a useful decision or reporting improvement without additional unsupported claims, and the measured latency and memory cost are acceptable. Mixed results should remain explicit rather than being reduced to a claim that the newer model is better.

Judge hosted adoption separately: useful gains must also justify recurring cost, data transfer and dependence on a working connection. A favorable result can justify an optional hosted mode while the local default remains available. A null result supports keeping the current setup; it cannot prove that every hosted model would fail to help.

Complete the fixed comparison even if it shows no improvement. Stop a run on its existing resource or failure limits and retain the failure. Do not extend the sample or rerun cases merely to obtain a favorable result. Qwen3.5 9B is an optional later candidate if the 4B result leaves a specific unresolved problem worth its extra resource cost.

## 4. Evaluate vision separately

After the text comparison, consider passing photos to the vision-capable controller to investigate dog presence, multiple subjects and subject visibility. This requires explicit image input and corresponding evidence and reporting rules. Merely changing the model name does not enable vision in BreedFrame.

Record this as a separate experiment because it changes the available evidence. Retain the ViT initially and test whether visual observations improve the workflow; do not assume a general vision model is a better breed classifier. Define the protocol before running it and disclose prior exposure to the comparison cases.

Use the same selected model with and without image input to measure the effect of vision. Comparing a local text-only controller directly with a hosted vision controller changes both model and evidence, so report that only as a comparison of complete systems. For hosted vision, identify which photos leave the Mac and include image-input charges.

## Candidate sources

Checked during the model discussion on 2026-09-11:

- [Ollama Qwen3.5 4B](https://ollama.com/library/qwen3.5:4b): Q4_K_M, approximately 3.4 GB download, image and tool support.
- [Ollama Qwen3.5 9B](https://ollama.com/library/qwen3.5:9b): Q4_K_M, approximately 6.6 GB download.
- [Qwen3.5 4B model card](https://huggingface.co/Qwen/Qwen3.5-4B): model capabilities, inference guidance and published comparisons with 9B.

Download sizes are not runtime memory estimates. Neither candidate has been benchmarked on this Mac in this task. Pin the actual downloaded model digest when implementing the comparison.
