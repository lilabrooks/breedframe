"""Fail visibly if the installed assets differ from the reviewed model identities."""

import json
from pathlib import Path
import httpx

ROOT = Path(__file__).resolve().parents[1]
DIGEST = "359d7dd4bcdab3d86b87d73ac27966f4dbb9f5efdfcc75d34a8764a09474fae7"

if __name__ == "__main__":
    config = json.loads((ROOT / "models/vit/config.json").read_text())
    assert len(config["id2label"]) == 120
    assert all(config["label2id"][label] == int(i) for i, label in config["id2label"].items())
    assert config["id2label"]["29"] == "curly" and config["id2label"]["113"] == "german_short"
    with httpx.Client(timeout=5, trust_env=False) as client:
        tags = client.get("http://127.0.0.1:11434/api/tags").json()["models"]
    if not any(m["name"] == "qwen3:4b" and m["digest"] == DIGEST for m in tags):
        raise SystemExit(
            "Expected pinned Qwen3 4B is unavailable. Stop any unrelated Ollama server, then run setup again. Do not silently substitute another model."
        )
    print("Verified published 120-class mapping and pinned local Qwen3 4B digest.")
