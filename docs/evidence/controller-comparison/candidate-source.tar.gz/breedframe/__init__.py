"""BreedFrame local assessment application."""
